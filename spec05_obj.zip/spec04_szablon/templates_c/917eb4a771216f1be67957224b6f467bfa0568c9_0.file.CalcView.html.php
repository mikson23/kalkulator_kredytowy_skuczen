<?php
/* Smarty version 4.3.4, created on 2024-01-12 11:16:28
  from 'C:\xampp\htdocs\spec04_szablon\app\CalcView.html' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '4.3.4',
  'unifunc' => 'content_65a1117cb208b1_14064921',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '917eb4a771216f1be67957224b6f467bfa0568c9' => 
    array (
      0 => 'C:\\xampp\\htdocs\\spec04_szablon\\app\\CalcView.html',
      1 => 1705054587,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_65a1117cb208b1_14064921 (Smarty_Internal_Template $_smarty_tpl) {
$_smarty_tpl->_loadInheritance();
$_smarty_tpl->inheritance->init($_smarty_tpl, true);
?>

<?php 
$_smarty_tpl->inheritance->instanceBlock($_smarty_tpl, 'Block_51663599465a1117cb177d8_82112086', "content");
?>




<?php $_smarty_tpl->inheritance->endChild($_smarty_tpl, "../templates/main.html");
}
/* {block "content"} */
class Block_51663599465a1117cb177d8_82112086 extends Smarty_Internal_Block
{
public $subBlocks = array (
  'content' => 
  array (
    0 => 'Block_51663599465a1117cb177d8_82112086',
  ),
);
public function callBlock(Smarty_Internal_Template $_smarty_tpl) {
?>
 <div class="row w-100">
	<div class="col-4"></div>

	<div class="card text-center col-4 p-4">
	<form action="<?php echo $_smarty_tpl->tpl_vars['conf']->value->app_url;?>
/app/calc.php" method="post">
		<div class="form-floating mb-3">
			<input type="number" class="form-control" id="id_x" name="x" placeholder="1" value="<?php echo $_smarty_tpl->tpl_vars['form']->value->x;?>
">
			<label for="id_x">Kwota kredytu:</label>
		</div>
		<div class="form-floating mb-3">
			<input type="text" class="form-control" id="id_o" name="o" placeholder="1" value="<?php echo $_smarty_tpl->tpl_vars['form']->value->o;?>
">
			<label for="id_o">Oprocentowanie:</label>
		</div>
		<div class="form-floating mb-3">
			<input type="number" class="form-control" id="id_y" name="y" placeholder="1" value="<?php echo $_smarty_tpl->tpl_vars['form']->value->y;?>
">
			<label for="id_y">Na ile miesięcy:</label>
		</div>
		
		
		<input type="submit" class="btn btn-outline-light" value="Oblicz" />
	</form>	


	<?php if ($_smarty_tpl->tpl_vars['msgs']->value->isError()) {?>
		
		<ol style="margin: 20px; padding: 10px 10px 10px 30px; border-radius: 5px;" class="bg-danger">
			<?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['msgs']->value->getErrors(), 'err');
$_smarty_tpl->tpl_vars['err']->do_else = true;
if ($_from !== null) foreach ($_from as $_smarty_tpl->tpl_vars['err']->value) {
$_smarty_tpl->tpl_vars['err']->do_else = false;
?>
				<li><?php echo $_smarty_tpl->tpl_vars['err']->value;?>
</li>
			<?php
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl, 1);?>
		</ol>
	<?php }?>
<div>
	<?php if ((isset($_smarty_tpl->tpl_vars['res']->value)) && (isset($_smarty_tpl->tpl_vars['rata']->value))) {?>
		<div style="margin: 20px; padding: 10px; border-radius: 5px;  " class='bg-success'>
			Koszt pożyczki: <?php echo $_smarty_tpl->tpl_vars['res']->value;?>
 zł<br>
			Rata miesięczna: <?php echo $_smarty_tpl->tpl_vars['rata']->value;?>
 zł<br>
		</div>
	<?php }?>
</div>

</div> 

<div class="col-4"></div>

</div> <?php
}
}
/* {/block "content"} */
}
