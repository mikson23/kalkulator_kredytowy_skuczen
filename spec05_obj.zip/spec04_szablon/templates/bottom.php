<footer class="d-flex flex-wrap justify-content-between align-items-center py-3 my-4 border-top p-2">
    <div class="col-md-4 d-flex align-items-center">
      
      <span class="mb-3 mb-md-0 text-body-secondary">© 2023 Mikołaj Skuczeń, Kalkulator Kredytowy</span>
    </div>

    <ul class="nav col-md-4 justify-content-end list-unstyled d-flex">
      <li class="ms-3"><a class="text-body-secondary" href="#">
      .
    </a></li>
      <li class="ms-3"><a class="text-body-secondary" href="#">
      .
    </a></li>
      <li class="ms-3"><a class="text-body-secondary" href="#">
      .
    </a></li>
    </ul>
  </footer>
</main>
<script src="https://getbootstrap.com/docs/5.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-C6RzsynM9kWDrMNeT87bh95OGNyZPhcTNXj1NW7RuBCsyN/o0jlpcV8Qyq46cDfL" crossorigin="anonymous"></script>

    </body>
</html>