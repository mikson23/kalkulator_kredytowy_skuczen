<?php
require_once 'Config.class.php';

session_start();

$role = isset($_SESSION['role']) ? $_SESSION['role'] : '';

if(empty($role)){
    include $conf->root_path.'/app/security/login.php';

    exit();
}