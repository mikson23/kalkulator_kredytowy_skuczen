<?php
class CalcResult {
	public $rata;
	public $result;	
} 