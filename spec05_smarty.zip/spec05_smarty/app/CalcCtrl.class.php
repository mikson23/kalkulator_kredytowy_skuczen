<?php

require_once $conf->root_path.'/lib/smarty/Smarty.class.php';
require_once $conf->root_path.'/lib/Messages.class.php';
require_once $conf->root_path.'/app/CalcForm.class.php';
require_once $conf->root_path.'/app/CalcResult.class.php';

class CalcCtrl {

    private $msgs;
    private $form;
    private $result;
    private $rata;

    public function __construct(){
		//stworzenie potrzebnych obiektów
		$this->msgs = new Messages();
		$this->form = new CalcForm();
		$this->result = new CalcResult();
	}
    public function getParams(){
        $this->form->x = isset($_REQUEST['x']) ? $_REQUEST['x'] : null;
        $this->form->y = isset($_REQUEST['y']) ? $_REQUEST['y'] : null;
        $this->form->o = isset($_REQUEST['o']) ? $_REQUEST['o'] : null;	
    }


    public function validate(){
        if ( ! (isset($this->form->x) && isset($this->form->y) && isset($this->form->o) )) {

        return false;
        }




        if ( $this->form->x == "") {
           $this->msgs->addError('Nie podano kwoty');
        }
        if ( $this->form->o == "") {
           $this->msgs->addError('Nie podano oprocentowania kredytu (RRSO)');
        }
        if ( $this->form->y == "") {
           $this->msgs->addError('Nie podano ilości rat / na ile miesięcy');
        }
        

        if (empty( $messages )) {
            
            
            if (! is_numeric( $this->form->x )) {
               $this->msgs->addError('Kwota kredytu nie jest prawidłowa');
            }
            
            if (! is_numeric( $this->form->y )) {
               $this->msgs->addError('Ilość miesięcy nie jest prawidłowa');
            }	
            if (! is_numeric( $this->form->o )) {
               $this->msgs->addError('Wartość oprocentowania jest nieprawidłowa');
            }
            //	uzależnienie liczenia raty od roli użytkownika
            if ( $_SESSION['role'] == "user" && $this->form->o < 10) {
                   $this->msgs->addError('Tylko administrator może brać kredyty z RRSO mniejszym niż 10%');
                }

        }

        return ! $this->msgs->isError();
    }

    public function process(){
        $this->getparams();
        if ($this->validate()) { 
            
            
            $this->form->x = intval($this->form->x);
            $this->form->y = intval($this->form->y);
            $this->form->o = floatval($this->form->o);
            
            
            $this->result = $this->form->x + $this->form->x*($this->form->y/12*($this->form->o/100));
            $this->rata = $this->result/$this->form->y;
            $this->rata = round($this->rata, 2);
            $this->result = round($this->result, 2);
        }
    $this->generateView();
    }

    public function generateView(){
		global $conf;
		
		$smarty = new Smarty();
		$smarty->assign('conf',$conf);
		
		$smarty->assign('page_title','Przykład 05');
		$smarty->assign('page_description','Obiektowość. Funkcjonalność aplikacji zamknięta w metodach różnych obiektów. Pełen model MVC.');
		$smarty->assign('page_header','Obiekty w PHP');
				
		$smarty->assign('msgs',$this->msgs);
		$smarty->assign('form',$this->form);
		$smarty->assign('res',$this->result);
		$smarty->assign('rata',$this->rata);
		
		$smarty->display($conf->root_path.'/app/CalcView.html');
	}

}